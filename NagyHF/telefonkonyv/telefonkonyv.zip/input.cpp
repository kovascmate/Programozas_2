#include "memtrace.h"
//ha valamilyen adat nincs megadva akkor ND/-1 jelölés van
#include "input.h"
#include <iostream>
#include <cstring>
//////////////////////////////////////////////////////////////////////////////////////////////////
///String
//konstruktor jó
//destruktor jó
String::String(char* input){
    int i = 0;
    while(input[i] != '\0')
    {
        ++i;
    }
    i++;
    meret = i;
    szoveg = new char[meret];
    strmasol(szoveg,input);
    szoveg[meret-1] = '\0';
}
void String::strmasol(char* ebbe,const char* ezt){
    int i = 0;
    do
    {
        ebbe[i] = ezt[i];
        i++;
    }while(ezt[i] != '\0');
}
String::~String(){
    delete[] this->szoveg;
}
//void operator<<(String& const adat){std::cout<<this->szoveg}
//////////////////////////////////////////////////////////////////////////////////////////////////
///Nev
char betu[] = "ND";
String nd(betu);
Nev::Nev(String vez= nd, String ker= nd,String bec= nd):vezetek(vez),kereszt(ker),becenev(bec){}
Nev::~Nev(){}
//void Nev::kiir(){std::cout<<getvezetek()<<" "<<getkereszt()<<std::endl;}
//////////////////////////////////////////////////////////////////////////////////////////////////
///Kontakt

Kontakt::Kontakt(int tel = -1,String mail = nd):telefonszam(tel),email(mail){}
Kontakt::~Kontakt(){}
//////////////////////////////////////////////////////////////////////////////////////////////////
//Munkahelyi
Munkahelyi::Munkahelyi(int tel = -1,String a = nd,int iroda = -1):Kontakt(tel,a),irodaszam(iroda){}
//////////////////////////////////////////////////////////////////////////////////////////////////
//Magan
Magan::Magan(int tel = -1,String a= nd,String rev = nd):Kontakt(tel,a),revolut(rev){}

//////////////////////////////////////////////////////////////////////////////////////////////////
///Nevjegy
//Nevjegy::Nevjegy():neve(Nev()),kontakt(Kontakt()),comment(){}
Nevjegy::~Nevjegy(){}
void Nevjegy::makevCard(){}
void Nevjegy::kiir()
{
    getvnev().print();
    getknev().print();
    getbnev().print();
    std::cout<<std::endl;

}
//////////////////////////////////////////////////////////////////////////////////////////////////
///Láncoltlista
Listaelem* elso;
//////////////////////////////////////////////////////////////////////////////////////////////////
///Más
