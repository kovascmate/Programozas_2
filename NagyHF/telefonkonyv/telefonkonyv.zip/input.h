#include "memtrace.h"
#ifndef INPUT_H
#define INPUT_H
#include <iostream>
#include "input.h"
/////////////////////////////////////////////////////////////////////
///  String osztaly segitsegevel taroljuk el az adatokat melyek szoveges formatumuak.
//
//Függvények:
//          -konstruktor
//          -destruktor
//          -strmasol:{
//                      ez a fuggveny bemeneten kapott char* tartalmat masolja at egy egy masik char* ba}
//          -getdata:{
//                      ez a fuggveny visszaadja a String altal tarolt szoveg kezdo pointeret}
//          -getmeret:{
//                      ez a fuggveny visszaadja a String altal tarolt adat meretet}
//          -print:{
//                      jelenleg ez a fuggveny felesleges, elavult}
//          -operator[]:{
//                      ennek az operatornak a segitsegevel lehetoseg lesz a String egy adott karakteret elerni, kereso fuggvenyhez szukseges}
//          -operator==:{
//                      kereso fuggveny prototipusakent van jelenleg elkepzelve}
//          -operator<<:{
//                      ennek az operatornak a segitsegevel lesz lehetseges kiiratni egy adott Stringet, kulonbozo ostreamekre}
/////////////////////////////////////////////////////////////////////

class String{
	int meret;
	char* szoveg;
	public:
	    String(char* input);
	    ~String();
	    void    strmasol(char* ebbe,const char* ezt);
	    char* getdata()   {return szoveg;}
	    int     getmeret()  {return meret;}
	    void operator<<(std::ostream& os)
	    {
	        char* mozgo = this->getdata();
	        for(int i = 0;i<this->getmeret();i++)
            {
                os<<mozgo[i];
            }
        }
	    void print()
	    {
	        for(int i = 0; i<meret;i++)
                {
                    std::cout<<szoveg[i]<<" ";
                }
	    }
        char operator[](int i)
        {
            return szoveg[i];
        }
        bool operator==(String hasonlito)
        {
            //bool egyezes = true;
            for(int i = 0; i < this->getmeret();i++)
            {
                for(int j = 0; j < hasonlito.getmeret();j++)
                {
                    if(this->getdata()[i] == hasonlito[j])
                    {
                       // int i_masolat = i;
                       // int j_masolat = j;
                            for(int k = 0; k < hasonlito.getmeret();k++)
                                {

                                }
                    }
                }
            }
            return true;
        }
};

/////////////////////////////////////////////////////////////////////
///  Nev osztaly tarolja majd a felhasznalok neveit a String osztaly segitsegevel
//
//Fuggvenyek:
//          -konstruktor
//          -destruktor
//          -getvezetek:{
//                          ennek a fuggvenynek a segitsegevel tudjuk majd elerni az adott Nevjegyek vezetekneveit}
//          -getkereszt:{
//                          ennek a fuggvenynek a segitsegevel tudjuk majd elerni az adott Nevjegyek keresztneveit}
//          -getbece:{
//                          ennek a fuggvenynek a segitsegevel tudjuk majd elerni az adott Nevjegyek beceneveit}
//          -kiir{
//                          jelenleg ez a fuggveny felesleges, listazas prototipusakent volt eltervezve}
/////////////////////////////////////////////////////////////////////

class Nev{
	String vezetek;
	String kereszt;
	String becenev;
	public:
	    Nev(String vez,String ker ,String bec);
        ~Nev();
        String getvezetek(){return vezetek.getdata();}
        String getkereszt(){return kereszt.getdata();}
        String getbece(){return becenev.getdata();}
        void kiir();
};

/////////////////////////////////////////////////////////////////////
/// Kontakt osztaly, ez egy ososztaly, belole szarmazik majd le a Munkahelyi es a Magan osztaly, felhasznalok elerhetosegit lehet itt tarolni
//
// Fuggvenyek:
//          -konstruktor
//          -destruktor
//          -gettel:{
//                      felhasznalo kontaktjaban levo telefonszam elereset biztositja,
//                      virtualis, tehat az alosztalyok fuggvenyei lesznek a lenyegesebbek}
//          -getemail:{
//                      felhasznalo kontaktjaban levo email elereset biztositja,
//                      virtualis, tehat az alosztalyok fuggvenyei lesznek a lenyegesebbek}
/////////////////////////////////////////////////////////////////////


class Kontakt{
    protected:
	int telefonszam;
	String email;
public:
    Kontakt(int tel,String mail);
    ~Kontakt();
    virtual int gettel(){return telefonszam;}
    virtual String getemail(){return email.getdata();}

};

/////////////////////////////////////////////////////////////////////
/// Munkahelyi osztaly, Kontakt osztaly leszarmazotja, munkahelyi adatok tarolasara szolgal
//
// Fuggvenyek:
//          -konstruktor
//          -destruktor
//          -gettel:{
//                      felhasznalo kontaktjaban levo telefonszam elereset biztositja}
//          -getemail:{
//                      felhasznalo kontaktjaban levo email elereset biztositja}
//          -getiroda:{
//                      felhasznalo kontaktjaban levo irodaszam elereset biztositja}
////////////////////////////////////////////////////////////////////

class Munkahelyi :public Kontakt{
	int irodaszam;
public:
    int getiroda(){return irodaszam;}
    Munkahelyi(int,String,int);
    int gettel(){return telefonszam;}
    String getemail(){return email.getdata();}
    ~Munkahelyi(){}
};

/////////////////////////////////////////////////////////////////////
/// Magan osztaly, Kontakt osztaly leszarmazotja, magan adatok tarolasara szolgal
//
// Fuggvenyek:
//          -konstruktor
//          -destruktor
//          -gettel:{
//                      felhasznalo kontaktjaban levo telefonszam elereset biztositja}
//          -getemail:{
//                      felhasznalo kontaktjaban levo email elereset biztositja}
//          -getrevolut:{
//                      felhasznalo kontaktjaban levo revolut felhasznalonev elereset biztositja}
/////////////////////////////////////////////////////////////////////

class Magan :public Kontakt{
	String revolut;
public:
    Magan(int,String,String);
    int gettel(){return telefonszam;}
    String getemail(){return email.getdata();}
    ~Magan(){}
    String getrevolut(){return revolut.getdata();}
};

/////////////////////////////////////////////////////////////////////
/// Nevjegy osztaly, minden adat osszefogo tarolasara szolgal
//
// Fuggvenyek:
//          -konstruktor
//          -destruktor
//          -getvnev:{
//                      adott felhasznalo vezetekneve eleresere szolgal}
//          -getknev:{
//                      adott felhasznalo keresztneve eleresere szolgal}
//          -getbnev:{
//                      adott felhasznalo beceneve eleresere szolgal}
//          -makevCard:{
//                      vCard-t keszit a parameterkent megkapott Nevjegybol}
//          -kiir:{
//                      jelenleg felesleges, listazas prototipusakent volt eltervezve}
/////////////////////////////////////////////////////////////////////

class Nevjegy{
	Nev neve;
	Kontakt* kontakt;
	String comment;
public:
    Nevjegy();
    ~Nevjegy();
    void makevCard();
    ////////////////////////////////////////////////
    String getvnev(){return neve.getvezetek();}
    String getknev(){return neve.getkereszt();}
    String getbnev(){return neve.getbece();}
    void kiir();

};

/////////////////////////////////////////////////////////////////////
/// Listaelem struktura, a Nevjegyek teljes tarolasara szolgal
/////////////////////////////////////////////////////////////////////

struct Listaelem
{
    Nevjegy nevjegy;
    Listaelem* kovetkezo;
public:
    void operator+(Nevjegy uj)
    {
        Listaelem* mozgo = this;
        while(mozgo != nullptr)
        {
            mozgo = mozgo->kovetkezo;
        }
        Listaelem vege;
        vege.nevjegy = uj;
        mozgo->kovetkezo = &vege;
        vege.kovetkezo = nullptr;
    }
    template <typename T>
    void operator>>(const T data)
    {
        fprintf(this,data);
    }

};



#endif // INPUT_H
