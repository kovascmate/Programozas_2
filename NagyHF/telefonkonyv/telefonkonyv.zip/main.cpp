#include "memtrace.h"
#include <iostream>
#include <cmath>
#include "input.h"
#include "filekezeles.h"
void uj_adat();
Nev nev_input();
void magan_elerhetoseg_input();
void munka_elerhetoseg_input();
int make_int(const char*); // nem jó
char* megjegyzes();
void konzol_kiir_lista(Listaelem*);
/*
std::ostream&(std::ostream& os, String& str)
{
    os<<str;
    return os;
}
*/



int main()
{
/*
char asd[41] = "11";
int a =make_int(asd);
std::cout<<a<<std::endl;*/
    char adat[2] = " ";
    bool kilep = false;
    do
    {
        std::cout<<"\tTelefonkonyv"     <<std::endl;
        std::cout<<"Lehetosegek:"       <<std::endl;
        std::cout<<"1. Listazas"        <<std::endl;
        std::cout<<"2. Uj adat"         <<std::endl;
        std::cout<<"3. Adat modositas"  <<std::endl;
        std::cout<<"4. Adat torles"     <<std::endl;
        std::cout<<"5. Kereses"         <<std::endl;
        std::cout<<"6. vCard keszites"  <<std::endl;
        std::cout<<"7. Kilepes"         <<std::endl;
        std::cin>>adat;
        int oszto = adat[0]-'0';
        switch(oszto)
        {
            ///listazas
            case 1:
                {
                //    listazas();
                    break;
                }
            case 2:
                uj_adat();
            break;
            ///adat_modositas
            case 3:
            break;
            ///adat_torles
            case 4:
            break;
            ///adat_kereses
            case 5:
            break;
            ///vCard keszites
            case 6:{

            break;
            }
            case 7:
                {
                    kilep = true;
                    break;
                }

        char bejon[100] = " ";
        std::cin>>bejon;
        String input(bejon);
        }

    }while(kilep != true);
    return 0;
}
void listazas(Listaelem* eleje = nullptr)
{
    if(eleje == nullptr)
    {
        eleje = betoltes();
        konzol_kiir_lista(eleje);
    }
    else
    {
        konzol_kiir_lista(eleje);
    }
}
void konzol_kiir_lista(Listaelem* eleje)
{
    Listaelem* mozgo = eleje;
    while(mozgo != nullptr)
    {
        mozgo->nevjegy.kiir();
        mozgo = mozgo->kovetkezo;
    }
    return;
}

void uj_adat()
{
    char adat[2];
    std::cout<<"Melyik adatot szeretne megadni?"<<std::endl;
    std::cout<<"1. Nev"                         <<std::endl;
    std::cout<<"2. Magan elerhetoseg"           <<std::endl;
    std::cout<<"3. Munkahelyi elerhetoseg"      <<std::endl;
    std::cout<<"4. Megjegyzes"                  <<std::endl;
    std::cin>>adat;
    int oszto = adat[0]-'0';
    switch (oszto)
        {
        case 1:
            nev_input();
            break;
        case 2:
            {
                magan_elerhetoseg_input();
                break;
            }
        case 3:
            {
                munka_elerhetoseg_input();
                break;
            }
        case 4:
            {
                char* comment = megjegyzes();
                String kesz_comment(comment);
                break;
            }
        default:
            break;
        }
}
Nev nev_input()
{
    bool munkamenetvege = false;
    char vezchartomb[100];
    char kerchartomb[100];
    char becchartomb[100];
    while(munkamenetvege == false)
    {
        char input[100];
        std::cout<<"Melyik adatot szeretne megadni?"<<std::endl;
        std::cout<<"1. Vezeteknev"<<std::endl;
        std::cout<<"2. Keresztnev"<<std::endl;
        std::cout<<"3. Becenev"<<std::endl;
        std::cout<<"4. Egyiket sem, mar vegeztem"<<std::endl;
        std::cin>>input;
        int oszto = input[0] - '0';
                std::cin>>input;
        switch (oszto)
            {
            case 1:
                {
                std::cin>>vezchartomb;
                break;
                }
            case 2:
                {
                std::cin>>kerchartomb;
                break;
                }
            case 3:
                {
                std::cin>>becchartomb;
                break;
                }
            case 4:
                {
                munkamenetvege = true;
                break;
                }
            default:
                break;
            }
    }
    String in_vez(vezchartomb);
    String in_ker(kerchartomb);
    String in_bec(becchartomb);
    Nev visszateres(in_vez,in_ker,in_bec);
    return visszateres;
}

void magan_elerhetoseg_input()
{
    bool munkamenetvege = false;

    char revolutchartomb[100];
    char magtelchartomb[100];
    char magemailchartomb[100];

    /*int magtelint;
    int revolutint;
*/
    while(munkamenetvege == false)
    {
        char adat[2];
        std::cout<<"Melyik adatot szeretne megadni?"        <<std::endl;
        std::cout<<"1. Magan telefonszam"                   <<std::endl;
        std::cout<<"2. Magan email"                         <<std::endl;
        std::cout<<"3. Revolut felhasznalonev"              <<std::endl;
        std::cout<<"4. Egyiket sem, mar vegeztem, kilepek." <<std::endl;
        std::cin>>adat;
        int oszto = adat[0]-'0';
        switch(oszto)
        {
        case 1:
            {
                std::cout<<"+";
                std::cin>>magtelchartomb;
                break;
            }
        case 2:
            {
                std::cin>>magemailchartomb;
                break;
            }
        case 3:
            {
                std::cin>>revolutchartomb;
                break;
            }
        case 4:
            {
                munkamenetvege = true;
                break;
            }
        }
    }
}

void munka_elerhetoseg_input()
{
    bool munkamenetvege = false;

    char muntelchartomb[100];
    char munemailchartomb[100];
    char irodaszamchartomb[100];

    int muntelint;
    int iroda;

    while(munkamenetvege == false)
    {
    char adat[2];
    std::cout<<"Melyik adatot szeretne megadni?"        <<std::endl;
    std::cout<<"1. Munkahelyi telefonszam"                   <<std::endl;
    std::cout<<"2. Munkahelyi email"                         <<std::endl;
    std::cout<<"3. Irodaszam"              <<std::endl;
    std::cout<<"4. Egyiket sem, mar vegeztem, kilepek." <<std::endl;
    std::cin>>adat;
    int oszto = adat[0]-'0';
    switch(oszto)
    {
    case 1:
        {
            std::cout<<"+";
            std::cin>>muntelchartomb;
        break;
        }
    case 2:
        {
            std::cin>>munemailchartomb;
        break;
        }
    case 3:
        {
            std::cin>>irodaszamchartomb;
            break;
        }
    case 4:
        {
            munkamenetvege = true;
            break;
        }
    default:
        {
            break;
        }
    }
    }//while vege
    muntelint      = make_int(muntelchartomb);
    String mun_email_string(munemailchartomb);
    iroda       = make_int(irodaszamchartomb);
    Munkahelyi munka(muntelint,mun_email_string,iroda);
}
char* megjegyzes()
{
    /*char input[500];
    std::cout<<"Itt hagyhat megjegyzest az adott nevjegyhez."<<std::endl;
    std::cin>>input;
    return input;
    */
    return nullptr;
}
int make_int(const char* ebbol)
{
    int ezt = 0;
    int i = 0;
    while(ebbol[i] != '\0')
    {
        if(ebbol[i] <= '9' && ebbol[i] >='0')
        i++;
        else
            throw "HIBA, NEM HELYES ERTEK LETT MEGADVA";
    }
    i++;
    for(int o = i;o>=0;o--)
    {
        ezt = ezt + pow(10,o);
    }
    return ezt;
}

Listaelem* keres(String keresett,Listaelem* eleje)
{
    Listaelem* mozgo = eleje;
    while(mozgo != nullptr)
    {
        while(1)
        {
            for(int j = 0; j <mozgo->nevjegy.getvnev().getmeret();j++) //amiben keresunk tag
            {
                for(int i = 0; i<keresett.getmeret();i++)               //amit keresunk tag
                {
                    if(keresett.getdata()[i] == '#')
                    {

                    }
                    else if(mozgo->nevjegy.getvnev()[i] == keresett.getdata()[j])
                    {

                    }
                    else if(mozgo->nevjegy.getvnev()[i] != keresett.getdata()[j])
                    {

                    }
                }
            }
        }
        mozgo = mozgo->kovetkezo;
    }
    return nullptr;
}
