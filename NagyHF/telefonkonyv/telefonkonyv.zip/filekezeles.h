#ifndef FILEKEZELES_H
#define FILEKEZELES_H
Listaelem* betoltes();
void mentes(Listaelem* mozgo);
#endif // FILEKEZELES_H
