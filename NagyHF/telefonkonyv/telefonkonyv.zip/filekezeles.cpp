#include "memtrace.h"
#include "input.h"
#include <fstream>

////////////////////////////////////////////////////
Listaelem* betoltes()
{
        Listaelem* eleje = nullptr;
        std::ifstream filepointer;
        filepointer.open("telefonkonyv.txt");
        //vezetek kereszt bece
        // nyiltel email irodaszam magan tel rev comment
        //Nevjegy be;
        while(filepointer.eof())
        {

        }
        filepointer.close();
        return eleje;
}
void mentes(Listaelem* mozgo)
{
    std::ofstream filepointer;
    filepointer.open("telefonkonyv.txt");
    while(mozgo != nullptr)
    {
//        filepointer<<mozgo->nevjegy.getvnev();
    }
    filepointer.close();
}
